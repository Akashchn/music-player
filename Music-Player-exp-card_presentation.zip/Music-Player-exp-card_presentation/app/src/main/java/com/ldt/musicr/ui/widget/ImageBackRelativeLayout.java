package com.ldt.musicr.ui.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.RelativeLayout;

public class ImageBackRelativeLayout extends RelativeLayout {
    public ImageBackRelativeLayout(Context context) {
        super(context);
    }

    public ImageBackRelativeLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public ImageBackRelativeLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
